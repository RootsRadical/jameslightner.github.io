// ====================
// James Lightner 
// CS-499: Artifact 2
// CS-300 Project Two Optimized Course Scheduler
// ====================

#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <sstream>
#include <fstream>
#include <unordered_map>
#include <algorithm>

using namespace std;

// ========== Course Struct ==========
struct Course {
    string courseNum;
    string courseName;
    vector<string> PreReqs;

    Course() = default;

    Course(string aCourseNum, string aCourseName, vector<string> prereqs = {}) {
        courseNum = aCourseNum;
        courseName = aCourseName;
        PreReqs = prereqs;
    }
};

// ========== CourseManager Class ==========
class CourseManager {
private:
    unordered_map<string, Course> courseMap;
    vector<Course> courses;

public:
    bool loadData(const string& filename);
    void printAllCourses();
    void printCourse(const string& courseNum);
};

// ========== Load Data from File ==========
bool CourseManager::loadData(const string& filename) {
    ifstream file(filename);
    if (!file.is_open()) {
        cout << "Failed to open file.\n";
        return false;
    }

    string line;
    while (getline(file, line)) {
        vector<string> tokens;
        stringstream ss(line);
        string token;

        while (getline(ss, token, ',')) {
            tokens.push_back(token);
        }

        if (tokens.size() < 2) continue;

        string courseNum = tokens[0];
        string courseName = tokens[1];
        vector<string> prereqs(tokens.begin() + 2, tokens.end());

        Course course(courseNum, courseName, prereqs);
        courses.push_back(course);
        courseMap[courseNum] = course;
    }

    file.close();
    return true;
}

// ========== Print All Courses (Sorted) ==========
void CourseManager::printAllCourses() {
    sort(courses.begin(), courses.end(), [](const Course& a, const Course& b) {
        return a.courseNum < b.courseNum;
        });

    for (const auto& course : courses) {
        cout << "Course Number: " << course.courseNum
            << "  Course Name: " << course.courseName
            << "  Prerequisite(s): ";

        if (course.PreReqs.empty()) {
            cout << "None";
        }
        else {
            for (const string& prereq : course.PreReqs) {
                cout << prereq << " ";
            }
        }
        cout << "\n";
    }
}

// ========== Print a Specific Course ==========
void CourseManager::printCourse(const string& courseNum) {
    auto it = courseMap.find(courseNum);
    if (it != courseMap.end()) {
        const Course& course = it->second;
        cout << "Course Number: " << course.courseNum
            << "  Course Name: " << course.courseName
            << "  Prerequisite(s): ";

        if (course.PreReqs.empty()) {
            cout << "None";
        }
        else {
            for (const string& prereq : course.PreReqs) {
                cout << prereq << " ";
            }
        }
        cout << "\n";
    }
    else {
        cout << "Course not found.\n";
    }
}

// ========== Main Program ==========
int main() {
    CourseManager manager;
    string courseNum;
    int choice = 0;

    cout << "Welcome to ABCU course scheduler\n\n";

    while (choice != 4) {
        cout << "**_____________________________**\n";
        cout << "||            MENU             ||\n";
        cout << "||-----------------------------||\n";
        cout << "||[1] Load Data Structure      ||\n";
        cout << "||[2] Print Course List        ||\n";
        cout << "||[3] Print Course             ||\n";
        cout << "||[4] Exit                     ||\n";
        cout << "||_____________________________||\n";
        cout << "Please enter your option: ";
        cin >> choice;

        switch (choice) {
        case 1:
            if (manager.loadData("ProjectCourseFile.txt")) {
                cout << "Course data loaded successfully.\n\n";
            }
            else {
                cout << "Failed to load course data.\n\n";
            }
            break;
        case 2:
            cout << "\nHere is a sample schedule:\n";
            cout << "----------------------------\n";
            manager.printAllCourses();
            cout << "\n";
            break;
        case 3:
            cout << "Please enter the course number you would like to search: ";
            cin >> courseNum;
            manager.printCourse(courseNum);
            cout << "\n";
            break;
        case 4:
            cout << "\nThank you for using the course planner!\n";
            break;
        default:
            cout << choice << " is not a valid option. Please enter a number 1 - 4.\n\n";
        }
    }

    return 0;
}
