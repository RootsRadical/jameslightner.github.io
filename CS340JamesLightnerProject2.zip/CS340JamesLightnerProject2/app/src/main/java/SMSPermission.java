package com.example.inventoryapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SMSPermissionActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_REQUEST_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        Button requestPermissionButton = findViewById(R.id.request_permission_button);

        // Check if SMS permission is already granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            // If permission is granted, proceed with notifications
            Toast.makeText(this, "SMS Permission already granted", Toast.LENGTH_SHORT).show();
            // navigate to the main screen or data screen here
        } else {
            // If permission is not granted, show the request button
            requestPermissionButton.setOnClickListener(v -> {
                // Request SMS permission
                ActivityCompat.requestPermissions(SMSPermissionActivity.this,
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_REQUEST_CODE);
            });
        }
    }

    // Handle the result of the request
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            // Check if the permission was granted
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                Toast.makeText(this, "Permission granted!", Toast.LENGTH_SHORT).show();
                // Proceed to the next screen or start sending SMS
            } else {
                // Permission denied
                Toast.makeText(this, "Permission denied. SMS notifications will not be available.", Toast.LENGTH_SHORT).show();
                // You can show a message explaining why this feature requires permission
            }
        }
    }
}
